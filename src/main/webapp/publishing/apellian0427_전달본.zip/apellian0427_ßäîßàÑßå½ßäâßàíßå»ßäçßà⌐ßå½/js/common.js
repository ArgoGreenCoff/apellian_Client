// Scroll Move
function scrollMove(t,h,m){
	"use strict";
	if(h==undefined) h=0;
	if(m!=undefined && jQuery(window).width()<993) h=m;
		var o = jQuery('html, body');
	if(navigator.userAgent.toLowerCase().match(/trident/i)){
		o = jQuery('html');
	}
	o.animate({
		scrollTop:jQuery(t).offset().top-h
	},500);
}

jQuery(function ($) {
	var $body = $('body'),
		$window = $(window),
		$wrap = $('#wrap');
	
	$('#ct .animated').addClass('ani-stop');
	function scrollSection(){
		var sT = $window.scrollTop();
		var wH = $window.height();
		$('#wrap').find('.px-motion').each(function(){
			var t = $(this);
			var tT = t.offset().top;
			var tH = t.innerHeight();
			var tD = 90;

			if(t.attr('data-delay')){
				tD = t.attr('data-delay');
			}
			if(tT-wH<sT-tD && tT+tH>sT && !$('body').hasClass('loading')){
				t.find('.animated').removeClass('ani-stop');
				if(t.find('video').length && !isNaN($('video').duration)){
					t.find('video')[0].play();
				}
			}else {
				t.find('.animated').addClass('ani-stop');
				if(t.find('video').length && !isNaN($('video').duration)){
					t.find('video')[0].pause();
					t.find('video')[0].currentTime  = 0;
				}
			}
		});
	}

	var lastScrollTop = 0;
	$window.scroll(function(){
		var sT = $(this).scrollTop(),
			lnbPosY;
		
		// up&down
		if(sT>lastScrollTop){
			$body.addClass('scroll-down');
			$body.removeClass('scroll-up');
		} else {
			$body.removeClass('scroll-down');
			$body.addClass('scroll-up');
		}
		lastScrollTop = sT;	
		
		if ($(this).scrollTop()>0) {
			$body.addClass('is-scroll');
		}else {
			$body.removeClass('is-scroll scroll-up');
		}
		if ($('.px-motion').length) {
			scrollSection();
		}
	}).trigger('scroll');
	
	if($('.sub-nav').length){
		var navPosY = $('.sub-nav').offset().top;
		
		$(window).scroll(function(){
			var sct = $(this).scrollTop();
			
			if(sct >= navPosY){
				$('#ct').addClass('sub-nav-fixed');
			}else{
				$('#ct').removeClass('sub-nav-fixed');
			}
		}).trigger('scroll');
	}
});